import {RouterModule, Routes} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {DashboardComponent} from './pages/dashboard/dashboard.component';
import {HomepageComponent} from './pages/homepage/homepage.component';
import {CandidateDashboardComponent} from "./pages/candidate-dashboard/candidate-dashboard.component";
import {CandidateProfileComponent} from "./pages/candidate-profile/candidate-profile.component";
import {CandidateSettingsComponent} from "./pages/candidate-settings/candidate-settings.component";
import {CandidateNotificationsComponent} from "./pages/candidate-notifications/candidate-notifications.component";
import {CandidatePaymentsComponent} from "./pages/candidate-payments/candidate-payments.component";
import {RecruiterDashboardComponent} from "./pages/recruiter-dashboard/recruiter-dashboard.component";
import {RecruiterProfileComponent} from "./pages/recruiter-profile/recruiter-profile.component";
import {RecruiterSettingsComponent} from "./pages/recruiter-settings/recruiter-settings.component";
import {RecruiterNotificationsComponent} from "./pages/recruiter-notifications/recruiter-notifications.component";


const routes: Routes = [
  {
      path: '',
      redirectTo: 'home',
      pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomepageComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'candidate',
    redirectTo: 'candidate/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'candidate/dashboard',
    component: CandidateDashboardComponent
  },
  {
    path: 'candidate/profile',
    component: CandidateProfileComponent,
  },
  {
    path: 'candidate/settings',
    component: CandidateSettingsComponent
  },
  {
    path: 'candidate/notifications',
    component: CandidateNotificationsComponent
  },
  {
    path: 'candidate/payments',
    component: CandidatePaymentsComponent
  },
  {
    path: 'recruiter',
    redirectTo: 'recruiter/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'recruiter/dashboard',
    component: RecruiterDashboardComponent
  },
  {
    path: 'recruiter/profile',
    component: RecruiterProfileComponent
  },
  {
    path: 'recruiter/settings',
    component: RecruiterSettingsComponent
  },
  {
    path: 'recruiter/notifications',
    component: RecruiterNotificationsComponent
  }

];

export const routingModule: ModuleWithProviders = RouterModule.forRoot(routes);

