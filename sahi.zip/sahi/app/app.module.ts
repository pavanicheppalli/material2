import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { RouterModule, Routes} from '@angular/router';

import { routingModule } from './app.routes';
import { LoginOptionsComponent } from './components/login-options/login-options.component';
import { LoginJobseekerComponent } from './components/login-jobseeker/login-jobseeker.component';
import { LoginJobposterComponent } from './components/login-jobposter/login-jobposter.component';
import { LoginForgotPasswordComponent } from './components/login-forgot-password/login-forgot-password.component';
import { CandidateDashboardComponent } from './pages/candidate-dashboard/candidate-dashboard.component';
import { CandidateSettingsComponent } from './pages/candidate-settings/candidate-settings.component';
import { CandidateProfileComponent } from './pages/candidate-profile/candidate-profile.component';
import { CandidatePaymentsComponent } from './pages/candidate-payments/candidate-payments.component';
import { RecruiterDashboardComponent } from './pages/recruiter-dashboard/recruiter-dashboard.component';
import { RecruiterProfileComponent } from './pages/recruiter-profile/recruiter-profile.component';
import { RecruiterSettingsComponent } from './pages/recruiter-settings/recruiter-settings.component';
import { CandidateSideMenuComponent } from './components/candidate-side-menu/candidate-side-menu.component';
import { CandidateMenuComponent } from './components/candidate-menu/candidate-menu.component';
import { RecruiterMenuComponent } from './components/recruiter-menu/recruiter-menu.component';
import { RecruiterSideMenuComponent } from './components/recruiter-side-menu/recruiter-side-menu.component';
import { CandidateNotificationsComponent } from './pages/candidate-notifications/candidate-notifications.component';
import { RecruiterNotificationsComponent } from './pages/recruiter-notifications/recruiter-notifications.component';
import { CandidateDashboardPanelComponent } from './components/candidate-dashboard-panel/candidate-dashboard-panel.component';
import { CandidateProfilePanelComponent } from './components/candidate-profile-panel/candidate-profile-panel.component';
import { CandidateNotificationsPanelComponent } from './components/candidate-notifications-panel/candidate-notifications-panel.component';
import { CandidatePaymentsPanelComponent } from './components/candidate-payments-panel/candidate-payments-panel.component';
import { CandidateSettingsPanelComponent } from './components/candidate-settings-panel/candidate-settings-panel.component';
import { RecruiterDashboardPanelComponent } from './components/recruiter-dashboard-panel/recruiter-dashboard-panel.component';
import { RecruiterNotificationsPanelComponent } from './components/recruiter-notifications-panel/recruiter-notifications-panel.component';
import { RecruiterProfilePanelComponent } from './components/recruiter-profile-panel/recruiter-profile-panel.component';
import { RecruiterSettingsPanelComponent } from './components/recruiter-settings-panel/recruiter-settings-panel.component';
import { CandidateTopMenuComponent } from './components/candidate-top-menu/candidate-top-menu.component';
import { RecruiterTopMenuComponent } from './components/recruiter-top-menu/recruiter-top-menu.component';


@NgModule({
  declarations: [
    AppComponent,
    
    HomepageComponent,
    DashboardComponent,
    LoginOptionsComponent,
    LoginJobseekerComponent,
    LoginJobposterComponent,
    LoginForgotPasswordComponent,
    CandidateDashboardComponent,
    CandidateSettingsComponent,
    CandidateProfileComponent,
    CandidatePaymentsComponent,
    RecruiterDashboardComponent,
    RecruiterProfileComponent,
    RecruiterSettingsComponent,
    CandidateSideMenuComponent,
    CandidateMenuComponent,
    RecruiterMenuComponent,
    RecruiterSideMenuComponent,
    CandidateNotificationsComponent,
    RecruiterNotificationsComponent,
    CandidateDashboardPanelComponent,
    CandidateProfilePanelComponent,
    CandidateNotificationsPanelComponent,
    CandidatePaymentsPanelComponent,
    CandidateSettingsPanelComponent,
    RecruiterDashboardPanelComponent,
    RecruiterNotificationsPanelComponent,
    RecruiterProfilePanelComponent,
    RecruiterSettingsPanelComponent,
    CandidateTopMenuComponent,
    RecruiterTopMenuComponent,
   
  ],
  imports: [
    BrowserModule,
    routingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
