import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterSideMenuComponent } from './recruiter-side-menu.component';

describe('RecruiterSideMenuComponent', () => {
  let component: RecruiterSideMenuComponent;
  let fixture: ComponentFixture<RecruiterSideMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterSideMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterSideMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
