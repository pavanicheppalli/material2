import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-side-menu',
  templateUrl: './recruiter-side-menu.component.html',
  styleUrls: ['./recruiter-side-menu.component.css']
})
export class RecruiterSideMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
