import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-jobseeker',
  templateUrl: './login-jobseeker.component.html',
  styleUrls: ['./login-jobseeker.component.scss']
})
export class LoginJobseekerComponent implements OnInit {

  SignInClicked = true;
  SignUpClicked = false;
  ForgotPasswordClicked = false;
  constructor() { }

  ngOnInit() {
  }

  OnSignInMenuItemClick(){
    this.SignUpClicked = false;
    this.SignInClicked = true;
    this.ForgotPasswordClicked = false;
  }

  OnSignUpMenuItemClick() {
    this.SignInClicked = false;
    this.SignUpClicked = true;
    this.ForgotPasswordClicked = false;
  }

  OnForgotPasswordButtonClick() {
    this.SignInClicked = false;
    this.SignUpClicked = false;
    this.ForgotPasswordClicked = true;
  }

  OnLoginButtonClick() {

  }

  OnSignUpButtonClick() {

  }
}
