import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginJobposterComponent } from './login-jobposter.component';

describe('LoginJobposterComponent', () => {
  let component: LoginJobposterComponent;
  let fixture: ComponentFixture<LoginJobposterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginJobposterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginJobposterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
