import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-jobposter',
  templateUrl: './login-jobposter.component.html',
  styleUrls: ['./login-jobposter.component.scss']
})
export class LoginJobposterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
