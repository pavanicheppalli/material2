import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatePaymentsPanelComponent } from './candidate-payments-panel.component';

describe('CandidatePaymentsPanelComponent', () => {
  let component: CandidatePaymentsPanelComponent;
  let fixture: ComponentFixture<CandidatePaymentsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidatePaymentsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidatePaymentsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
