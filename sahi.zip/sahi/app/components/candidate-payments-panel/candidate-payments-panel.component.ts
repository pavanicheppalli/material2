import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-payments-panel',
  templateUrl: './candidate-payments-panel.component.html',
  styleUrls: ['./candidate-payments-panel.component.css']
})
export class CandidatePaymentsPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
