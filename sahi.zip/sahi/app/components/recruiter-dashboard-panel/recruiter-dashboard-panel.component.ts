import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-dashboard-panel',
  templateUrl: './recruiter-dashboard-panel.component.html',
  styleUrls: ['./recruiter-dashboard-panel.component.css']
})
export class RecruiterDashboardPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
