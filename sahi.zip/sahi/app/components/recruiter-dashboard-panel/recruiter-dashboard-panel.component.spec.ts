import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterDashboardPanelComponent } from './recruiter-dashboard-panel.component';

describe('RecruiterDashboardPanelComponent', () => {
  let component: RecruiterDashboardPanelComponent;
  let fixture: ComponentFixture<RecruiterDashboardPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterDashboardPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterDashboardPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
