import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-profile-panel',
  templateUrl: './recruiter-profile-panel.component.html',
  styleUrls: ['./recruiter-profile-panel.component.css']
})
export class RecruiterProfilePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
