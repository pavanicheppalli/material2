import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterProfilePanelComponent } from './recruiter-profile-panel.component';

describe('RecruiterProfilePanelComponent', () => {
  let component: RecruiterProfilePanelComponent;
  let fixture: ComponentFixture<RecruiterProfilePanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterProfilePanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterProfilePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
