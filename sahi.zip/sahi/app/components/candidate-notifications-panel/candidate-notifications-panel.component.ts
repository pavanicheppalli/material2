import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-notifications-panel',
  templateUrl: './candidate-notifications-panel.component.html',
  styleUrls: ['./candidate-notifications-panel.component.css']
})
export class CandidateNotificationsPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
