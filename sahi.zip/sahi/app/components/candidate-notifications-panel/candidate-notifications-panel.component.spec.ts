import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateNotificationsPanelComponent } from './candidate-notifications-panel.component';

describe('CandidateNotificationsPanelComponent', () => {
  let component: CandidateNotificationsPanelComponent;
  let fixture: ComponentFixture<CandidateNotificationsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateNotificationsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateNotificationsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
