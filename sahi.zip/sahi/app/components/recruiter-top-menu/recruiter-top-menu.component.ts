import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-top-menu',
  templateUrl: './recruiter-top-menu.component.html',
  styleUrls: ['./recruiter-top-menu.component.css']
})
export class RecruiterTopMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
