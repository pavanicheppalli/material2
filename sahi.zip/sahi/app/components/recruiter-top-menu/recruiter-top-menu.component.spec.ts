import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterTopMenuComponent } from './recruiter-top-menu.component';

describe('RecruiterTopMenuComponent', () => {
  let component: RecruiterTopMenuComponent;
  let fixture: ComponentFixture<RecruiterTopMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterTopMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterTopMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
