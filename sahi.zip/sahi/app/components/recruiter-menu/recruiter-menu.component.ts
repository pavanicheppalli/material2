import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-menu',
  templateUrl: './recruiter-menu.component.html',
  styleUrls: ['./recruiter-menu.component.css']
})
export class RecruiterMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
