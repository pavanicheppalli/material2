import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-notifications-panel',
  templateUrl: './recruiter-notifications-panel.component.html',
  styleUrls: ['./recruiter-notifications-panel.component.css']
})
export class RecruiterNotificationsPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
