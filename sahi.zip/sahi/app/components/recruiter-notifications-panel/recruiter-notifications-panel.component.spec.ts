import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterNotificationsPanelComponent } from './recruiter-notifications-panel.component';

describe('RecruiterNotificationsPanelComponent', () => {
  let component: RecruiterNotificationsPanelComponent;
  let fixture: ComponentFixture<RecruiterNotificationsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterNotificationsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterNotificationsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
