import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-settings-panel',
  templateUrl: './candidate-settings-panel.component.html',
  styleUrls: ['./candidate-settings-panel.component.css']
})
export class CandidateSettingsPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
