import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateSettingsPanelComponent } from './candidate-settings-panel.component';

describe('CandidateSettingsPanelComponent', () => {
  let component: CandidateSettingsPanelComponent;
  let fixture: ComponentFixture<CandidateSettingsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateSettingsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateSettingsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
