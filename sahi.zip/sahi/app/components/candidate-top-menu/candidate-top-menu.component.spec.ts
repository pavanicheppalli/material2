import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateTopMenuComponent } from './candidate-top-menu.component';

describe('CandidateTopMenuComponent', () => {
  let component: CandidateTopMenuComponent;
  let fixture: ComponentFixture<CandidateTopMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateTopMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateTopMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
