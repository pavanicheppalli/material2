import { Component, OnInit } from '@angular/core';
declare var jQuery:any;
declare var $: any;

@Component({
  selector: 'app-candidate-top-menu',
  templateUrl: './candidate-top-menu.component.html',
  styleUrls: ['./candidate-top-menu.component.css']
})
export class CandidateTopMenuComponent implements OnInit {

  constructor() { 
    jQuery('.ui.dropdown').dropdown();
  }

  ngOnInit() {
  }

}
