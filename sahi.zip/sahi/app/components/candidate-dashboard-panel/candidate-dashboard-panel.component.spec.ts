import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateDashboardPanelComponent } from './candidate-dashboard-panel.component';

describe('CandidateDashboardPanelComponent', () => {
  let component: CandidateDashboardPanelComponent;
  let fixture: ComponentFixture<CandidateDashboardPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateDashboardPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateDashboardPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
