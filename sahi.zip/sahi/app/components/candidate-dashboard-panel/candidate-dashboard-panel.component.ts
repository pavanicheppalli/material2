import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-dashboard-panel',
  templateUrl: './candidate-dashboard-panel.component.html',
  styleUrls: ['./candidate-dashboard-panel.component.css']
})
export class CandidateDashboardPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
