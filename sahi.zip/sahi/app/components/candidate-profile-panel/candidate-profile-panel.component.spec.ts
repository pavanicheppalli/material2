import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateProfilePanelComponent } from './candidate-profile-panel.component';

describe('CandidateProfilePanelComponent', () => {
  let component: CandidateProfilePanelComponent;
  let fixture: ComponentFixture<CandidateProfilePanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateProfilePanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateProfilePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
