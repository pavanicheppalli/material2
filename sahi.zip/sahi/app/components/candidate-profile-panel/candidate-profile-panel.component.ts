import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-profile-panel',
  templateUrl: './candidate-profile-panel.component.html',
  styleUrls: ['./candidate-profile-panel.component.css']
})
export class CandidateProfilePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
