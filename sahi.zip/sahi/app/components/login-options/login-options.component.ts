import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-options',
  templateUrl: './login-options.component.html',
  styleUrls: ['./login-options.component.scss']
})
export class LoginOptionsComponent implements OnInit {

  JobSeekerClicked = false;
  JobPostingClicked  = false;
  NothingClicked = true;
  constructor() { }
  ngOnInit() {
    // this.onJobSeekerButtonclick();
  }

  onJobSeekerButtonclick() {
    this.NothingClicked = false;
    this.JobPostingClicked = false;
    this.JobSeekerClicked = true;
  }

  onJobPostingButtonClick() {
    this.NothingClicked = false;
    this.JobSeekerClicked = false;
    this.JobPostingClicked = true;
  }

  OnBackButtonClick() {
    this.NothingClicked = true;
    this.JobPostingClicked = false;
    this.JobSeekerClicked = false;
  }

}
