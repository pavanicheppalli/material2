import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterSettingsPanelComponent } from './recruiter-settings-panel.component';

describe('RecruiterSettingsPanelComponent', () => {
  let component: RecruiterSettingsPanelComponent;
  let fixture: ComponentFixture<RecruiterSettingsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterSettingsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterSettingsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
