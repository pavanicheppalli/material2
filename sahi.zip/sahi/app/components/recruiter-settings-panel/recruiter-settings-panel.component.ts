import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-settings-panel',
  templateUrl: './recruiter-settings-panel.component.html',
  styleUrls: ['./recruiter-settings-panel.component.css']
})
export class RecruiterSettingsPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
