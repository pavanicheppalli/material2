import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-menu',
  templateUrl: './candidate-menu.component.html',
  styleUrls: ['./candidate-menu.component.css']
})
export class CandidateMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
