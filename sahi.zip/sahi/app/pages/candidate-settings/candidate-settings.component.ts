import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-settings',
  templateUrl: './candidate-settings.component.html',
  styleUrls: ['./candidate-settings.component.css']
})
export class CandidateSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
