import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-settings',
  templateUrl: './recruiter-settings.component.html',
  styleUrls: ['./recruiter-settings.component.css']
})
export class RecruiterSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
