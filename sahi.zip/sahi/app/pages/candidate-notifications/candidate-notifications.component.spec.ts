import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateNotificationsComponent } from './candidate-notifications.component';

describe('CandidateNotificationsComponent', () => {
  let component: CandidateNotificationsComponent;
  let fixture: ComponentFixture<CandidateNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidateNotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
