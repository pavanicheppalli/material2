import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-notifications',
  templateUrl: './candidate-notifications.component.html',
  styleUrls: ['./candidate-notifications.component.css']
})
export class CandidateNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
