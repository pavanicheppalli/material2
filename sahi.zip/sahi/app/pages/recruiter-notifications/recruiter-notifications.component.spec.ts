import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecruiterNotificationsComponent } from './recruiter-notifications.component';

describe('RecruiterNotificationsComponent', () => {
  let component: RecruiterNotificationsComponent;
  let fixture: ComponentFixture<RecruiterNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecruiterNotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecruiterNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
