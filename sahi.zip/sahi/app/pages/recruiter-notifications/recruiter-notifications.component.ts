import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-notifications',
  templateUrl: './recruiter-notifications.component.html',
  styleUrls: ['./recruiter-notifications.component.css']
})
export class RecruiterNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
