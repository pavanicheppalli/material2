import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-payments',
  templateUrl: './candidate-payments.component.html',
  styleUrls: ['./candidate-payments.component.css']
})
export class CandidatePaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
