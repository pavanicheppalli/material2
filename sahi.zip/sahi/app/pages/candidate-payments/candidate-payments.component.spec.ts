import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatePaymentsComponent } from './candidate-payments.component';

describe('CandidatePaymentsComponent', () => {
  let component: CandidatePaymentsComponent;
  let fixture: ComponentFixture<CandidatePaymentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidatePaymentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidatePaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
