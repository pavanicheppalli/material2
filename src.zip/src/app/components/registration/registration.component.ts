import { Component, OnInit, Input } from '@angular/core';



export interface Role {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'abe-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  @Input() name;

  @Input() email = "";
  @Input() password = "";
  @Input() confirm_password  = "";
  @Input() phone_Number = "";

  email_help_string = "";
  password_help_string  = "";
  phone_number_help_string = "";

  password_visibile  = false;
  input_icon  = "visibility_off"; // can be visibility_off or visibility
  input_type  = "password"; // can be text/password based on password_visibility
  roles: Role[] = [
    {value: 'patient-0', viewValue: 'Patient'},
    {value: 'medicalshop-1', viewValue: 'Medical Shop'},
    {value: 'admin-2', viewValue: 'Admin'}
  ];

  constructor() { }


  ngOnInit() {
  }

  toggle_password_visibility() {
    if(this.password_visibile){
      this.password_visibile = false;
      this.input_icon = "visibility_off";
      this.input_type = "password";
    }
    else{
      this.password_visibile = true;
      this.input_icon = "visibility";
      this.input_type = "text";
    }
  }

  validate_email(){
    let length = this.email.length;
    if ( length == 0) return false;
    if ( length > 32) return false;
    return true;
  }

  validate_password(){
    let length = this.password.length;
    if ( length == 0) return false;
    if ( length > 32) return false;
    return true;
  }

  validate_phone_number(){
    if(this.phone_Number.length < 10 || this.phone_Number.length>13){
      return false;
    }
    else if( this.phone_Number[0] == '+' && this.phone_Number.length != 13){
      return false;
    }
    else{
      for( let i = 0 ; i < this.phone_Number.length ; ++i ){
        if( this.phone_Number.charAt(i) == '+'){
          if( i != 0 ) return false;
        }
        if( this.phone_Number.charAt(i) < '0' || this.phone_Number.charAt(i) > '9'){
          return false;
        }
      }
      return true;
    }
  }

  register() {
    console.log("login triggered");
    console.log(this.email);
    console.log(this.password);
    this.email = this.email.trim();
    this.password = this.password.trim();
    this.phone_Number = this.phone_Number.trim();
    let email_validated = this.validate_email();
    let password_validated = this.validate_password();
    let phone_number_validated = this.validate_phone_number();
    console.log(email_validated);
    console.log(password_validated);
    console.log(phone_number_validated);
    if (email_validated == false){
      this.email_help_string = "email validation failed";
    }
    else if (password_validated == false) {
      this.password_help_string = "password validation failed";
    }
    else if (phone_number_validated == false){
      this.phone_number_help_string = "Phone Number Validation Failed";
    }
    else {
      // send http request to check whether credentials are correct or not
    }
  }
}
