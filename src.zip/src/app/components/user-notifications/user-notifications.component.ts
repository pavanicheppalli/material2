import { Component, OnInit } from '@angular/core';

export interface Notification{
  Doctor: string;
  Hospital: string,
  Location: string,
  Time: string,
  Date: string,
  Status: string
};



@Component({
  selector: 'abe-user-notifications',
  templateUrl: './user-notifications.component.html',
  styleUrls: ['./user-notifications.component.scss']
})
export class UserNotificationsComponent implements OnInit {
  notifications: Notification[] = [
    {
      'Doctor' : 'Mahendhar Gejelli',
      'Hospital' : 'Columbia Asia hospital',
      'Location': 'WhiteField',
      'Time' : '12:30 PM',
      'Date': '21 Jan 2018',
      'Status' : 'Approved'
    },
    {
      'Doctor' : 'Akhil Kumar Reddy',
      'Hospital' : 'Apollo Hospital',
      'Location': 'Varthur',
      'Time' : '2:30 PM',
      'Date': '24 Jan 2018',
      'Status' : 'Rejected'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Pending'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Pending'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Pending'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Rejected'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Pending'
    },
    {
      'Doctor' : 'Kiran Kumar',
      'Hospital' : 'Chalmeda Hospital',
      'Location': 'Siddipet',
      'Time' : '9:30 AM',
      'Date': '25 Jan 2018',
      'Status' : 'Approved'
    }
  ];
  dataSource = this.notifications;
  displayedColumns = ['Doctor','Hospital','Location','Date', 'Time', 'Status'];
  constructor() { }

  ngOnInit() {
  }

}
