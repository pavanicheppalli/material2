import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'abe-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  @Input() email;
  @Input() password;

  password_visibile  = false;
  input_icon  = "visibility_off"; // can be visibility_off or visibility
  input_type  = "password"; // can be text/password based on password_visibility

  email_help_string  = "";
  password_help_string  = "";

  constructor() { }

  ngOnInit() {
  }

  toggle_password_visibility() {
    if(this.password_visibile){
      this.password_visibile = false;
      this.input_icon = "visibility_off";
      this.input_type = "password";
    }
    else{
      this.password_visibile = true;
      this.input_icon = "visibility";
      this.input_type = "text";
    }
  }

  validate_email(){
    let length = this.email.length;
    if ( length == 0) return false;
    if ( length > 32) return false;
    return true;
  }

  validate_password(){
    let length = this.password.length;
    if ( length == 0) return false;
    if ( length > 32) return false;
    return true;
  }

  login() {
    console.log("login triggered");
    console.log(this.email);
    console.log(this.password);
    this.email = this.email.trim();
    this.password = this.password.trim();
    let email_validated = this.validate_email();
    let password_validated = this.validate_password();
    console.log(email_validated);
    console.log(password_validated);
    if (email_validated == false){
      this.email_help_string = "email validation failed";
    }
    else if (password_validated == false) {
      this.password_help_string = "password validation failed";
    }
    else {
      // send http request to check whether credentials are correct or not
    }
  }

}
