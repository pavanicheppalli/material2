
export class Registration{
    id:number;
    name: String;
    email:String;
    password:String;
    confirmpassword:String;
    role:String;
    mobile:number;
}