import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HcwService {
  private baseUrl = 'http://localhost:8011/api/auth'
  constructor( private  http: HttpClient) {}

  registerUser(reg: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/signup`, reg);
  } 
}
