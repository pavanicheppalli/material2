import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HealthcareHomepageComponent } from './pages/healthcare-homepage/healthcare-homepage.component';
import { LoginPageComponent } from './pages/login-page/login-page.component';
import { RegistrationPageComponent } from './pages/registration-page/registration-page.component';
import { UserNotificationsPageComponent } from './pages/user-notifications-page/user-notifications-page.component';

const routes: Routes = [
  
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',  component: HealthcareHomepageComponent },
  { path: 'user/register', component: RegistrationPageComponent },
  { path: 'user/login', component: LoginPageComponent },
  { path: 'user/notifications', component: UserNotificationsPageComponent }
   
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes) 
  
  ],
  exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }
