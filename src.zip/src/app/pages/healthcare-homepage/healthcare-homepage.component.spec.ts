import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthcareHomepageComponent } from './healthcare-homepage.component';

describe('HealthcareHomepageComponent', () => {
  let component: HealthcareHomepageComponent;
  let fixture: ComponentFixture<HealthcareHomepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HealthcareHomepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthcareHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
