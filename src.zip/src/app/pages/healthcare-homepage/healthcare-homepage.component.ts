import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'abe-healthcare-homepage',
  templateUrl: './healthcare-homepage.component.html',
  styleUrls: ['./healthcare-homepage.component.scss']
})
export class HealthcareHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
