import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'abe-user-notifications-page',
  templateUrl: './user-notifications-page.component.html',
  styleUrls: ['./user-notifications-page.component.scss']
})
export class UserNotificationsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
