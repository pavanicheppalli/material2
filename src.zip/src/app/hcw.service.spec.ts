import { TestBed, inject } from '@angular/core/testing';

import { HcwService } from './hcw.service';

describe('HcwService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HcwService]
    });
  });

  it('should be created', inject([HcwService], (service: HcwService) => {
    expect(service).toBeTruthy();
  }));
});
